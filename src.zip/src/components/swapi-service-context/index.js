import {
  SwapiServiceProvider,
  SwapiServiceConsumer
} from './swapi-service-context'

export {
  SwapiServiceProvider,
  SwapiServiceConsumer
};
